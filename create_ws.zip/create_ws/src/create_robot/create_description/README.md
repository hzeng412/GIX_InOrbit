# create_description

A place for URDF models and meshes for iRobot's Create 1 and 2.

## Sources

* Original URDF and Create 1 mesh:  https://github.com/turtlebot/turtlebot_create
* Original Create 2 mesh:  https://github.com/goncabrita/roomba_robot
