^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package create_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.0 (2018-06-10)
------------------
* Migrate to package.xml format 2
    * Minor linting to package files.
* Add support for defining and playing songs
* Refactor CMakeLists.txt and package.xml files and add missing install rules
* Contributors: Clyde McQueen, Jacob Perron

1.2.0 (2016-10-07)
------------------

1.1.0 (2016-07-23)
------------------

1.0.1 (2016-05-24)
------------------
* Add Bumper message with contact sensor states and light sensor states
* Add header to all custom message types
* Contributors: Jacob Perron

1.0.0 (2016-04-01)
------------------
* Add ChargingState and Mode messages
* Add charging state and mode publishers
* Add 'ca_msgs' package
* Contributors: Jacob Perron
